
library(testthat)
library(mockthat)

test_check("mockthat")
