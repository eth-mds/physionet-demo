# mockthat 0.2.8

* Remove some tests: due to an internal change in jsonlite, this is no longer
  a useful example.

# mockthat 0.2.7

* Bugfix.

# mockthat 0.2.6

* Fix return objects with length > 1

# mockthat 0.2.5

* Fix mocking imported functions

# mockthat 0.2.4

* CRAN re-submission now with minor fix of hard-coding base pkg names as
  returned by `tools:::.get_standard_package_names()$base` instead of calling
  `utils::installed.packages()`.

# mockthat 0.2.3

* save multiple calls and associated args

# mockthat 0.2.2

* CRAN re-submission now with `mocktest` tests being dependent on
  availability of `mocktest`

# mockthat 0.2.1

* add `arg` argument to `mock_args()`

# mockthat 0.2.0

* add `local_mock()` and arg/call caching

# mockthat 0.1.1

* Submitted to CRAN

# mockthat 0.1.0

* Added a `NEWS.md` file to track changes to the package.
